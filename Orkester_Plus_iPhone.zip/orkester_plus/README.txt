ORKester+ – iPhone prototip

POMEMBNO:
Če HTML odpreš neposredno v aplikaciji Datoteke na iPhonu, iOS lahko pokaže samo predogled in ne izvaja JavaScripta. Zato se gumbi ne odzivajo. To ni zato, ker bi bili gumbi namenoma neaktivni.

ZA PRAVO UPORABO NA IPHONU:
Orkester+ mora biti odprt prek spletnega naslova (HTTPS), ne kot lokalni predogled datoteke.

V tej različici je uporabniški vmesnik pripravljen za mobilni zaslon in vsebuje:
- navigacijo Domov / Dogodki / Člani / Več
- dodajanje dogodkov
- podrobnosti dogodkov
- potrditev udeležbe
- dodajanje članov
- iskanje članov
- podskupine
- koledar
- obvestila

Za naslednji korak je treba aplikacijo objaviti na HTTPS naslovu (npr. lastno gostovanje ali GitHub Pages). Nato jo v Safariju odpreš in izbereš 'Add to Home Screen'.
